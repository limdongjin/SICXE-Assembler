#ifndef __COMMAND_MACRO_H__
#define __COMMAND_MACRO_H__

#define COMPARE_STRING(T, S) (strcmp ((T), (S)) == 0)
#define COMMAND_MAX_LEN 510
#define TOKEN_MAX_NUM 30

#endif
